--# Not In Use.
--# Logon your main characters before deleting the folder containing this file
--|
--+ Note: 
--+ This folder will remain in the distribution for some time, to allow the majoring time to update. 
--+ It uses no CPU and a tiny amount of RAM.

HealBot_Timers_setLuVars("oldDataExists", true)