-- French translator required

------------
-- FRENCH --
------------
--
-- ࠽ \195\160
-- ⠽ \195\162
-- 砽 \195\167
-- 蠽 \195\168
-- 頽 \195\169
-- ꠽ \195\170
--  \195\174
--  \195\175
-- 𠽠\195\180
-- û = \195\187
-- À = \195\128
-- Ƞ= \195\136
-- ɠ= \195\137
-- ʠ= \195\138
-- espace avant ':' (?) = \194\160


function HealBot_Lang_Options_frFR()
    -- Translator required - Chat on Discord to get started
end
