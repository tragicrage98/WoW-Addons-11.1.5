-- Russian translator required

-------------
-- RUSSIAN --
-------------
--
--
--
--

function HealBot_Lang_Options_ruRU()
    -- Translator required - Chat on Discord to get started
end
