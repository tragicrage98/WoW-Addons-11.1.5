-- Brazilian translator required

---------------
-- Brazilian --
---------------
--
--
--
--
--
--
--
--

function HealBot_Lang_Options_ptBR()
    -- Translator required - Chat on Discord to get started
end
