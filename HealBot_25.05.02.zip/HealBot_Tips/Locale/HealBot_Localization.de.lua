-- German translator required

------------
-- GERMAN --
------------
--
-- Ä = \195\132
-- Ö = \195\150
-- Ü = \195\156
-- ß = \195\159
-- ä = \195\164
-- ö = \195\182
-- ü = \195\188
--

function HealBot_Lang_Options_deDE()
    -- Translator required - Chat on Discord to get started
end
