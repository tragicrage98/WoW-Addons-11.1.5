-- Taiwanese translator required

---------------
-- TAIWANESE --
---------------
--
-- 
--

function HealBot_Lang_Options_zhTW()
    -- Translator required - Chat on Discord to get started
end
