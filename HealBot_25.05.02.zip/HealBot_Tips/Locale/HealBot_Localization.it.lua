-- Italian translator required

-------------
-- ITALIAN --
-------------
--
--
--
--

function HealBot_Lang_Options_itIT()
    -- Translator required - Chat on Discord to get started
end
