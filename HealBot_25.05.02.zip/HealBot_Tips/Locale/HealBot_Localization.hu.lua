-- Hungarian translator required

---------------
-- HUNGARIAN --
---------------
--
--
--
--

function HealBot_Lang_Options_huHU()
    -- Translator required - Chat on Discord to get started
end
