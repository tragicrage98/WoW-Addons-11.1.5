-- Chinese translator required

-------------
-- CHINESE --
-------------
--
--
--
--

function HealBot_Lang_Options_zhCN()
    -- Translator required - Chat on Discord to get started
end
