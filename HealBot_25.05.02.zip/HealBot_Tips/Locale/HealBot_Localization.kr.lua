-- Korean translator required

-------------
-- KOREAN --
-------------
--
--
--
--

function HealBot_Lang_Options_koKR()
    -- Translator required - Chat on Discord to get started
end
