-- Spanish translator required

-------------
-- SPANISH
--
-- á = \195\161
-- é = \195\169    
-- í = \195\173
-- ó = \195\179
-- ú = \195\186
-- ñ = \195\177
--
--


function HealBot_Lang_Options_esALL()
    -- Translator required - Chat on Discord to get started
end
