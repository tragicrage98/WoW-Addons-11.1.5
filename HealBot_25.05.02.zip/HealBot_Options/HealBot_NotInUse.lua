--# Not In Use.
--# Delete the folder containing this file
--|
--+ Note: This folder will remain in the distribution for a short time. 
--+ It uses no CPU and a tiny amount of RAM.

HealBot_Timers_setLuVars("oldOptionsExists", true)