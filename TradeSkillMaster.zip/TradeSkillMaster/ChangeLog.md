## v4.14.36 Changes

* [Retail] Updated for patch 11.1.5

[Known Issues](https://support.tradeskillmaster.com/en_US/known_issues)
