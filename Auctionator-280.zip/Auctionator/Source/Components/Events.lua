Auctionator.Components.Events = {
  EnterPressed = "components_enter_pressed",
}
