Auctionator.Constants.DialogNames = {
  CreateShoppingList = "AUCTIONATOR_CREATE_SHOPPING_LIST",
  DeleteShoppingList = "AUCTIONATOR_DELETE_SHOPPING_LIST",
  RenameShoppingList = "AUCTIONATOR_RENAME_SHOPPING_LIST",
  MakePermanentShoppingList = "auctionator_make_permanent_shopping_list",

  SellingConfirmPost = "AUCTIONATOR_SELLING_CONFIRM_POST",
  SellingConfirmPostSkip = "AUCTIONATOR_SELLING_CONFIRM_POST_SKIP",
  SellingConfirmUnhideAll = "AUCTIONATOR_SELLING_CONFIRM_UNHIDE_ALL",
}
