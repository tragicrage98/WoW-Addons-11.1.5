Auctionator.Constants.Durations = {
  Short = 2,
  Medium = 8,
  Long = 24,
}
