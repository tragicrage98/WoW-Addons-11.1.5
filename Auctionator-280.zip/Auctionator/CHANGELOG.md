# Auctionator

## [280](https://github.com/Auctionator/Auctionator/tree/280) (2025-05-16)
[Full Changelog](https://github.com/Auctionator/Auctionator/compare/279...280) 

- Prevent auto-generated toc overwriting Wrath toc  
