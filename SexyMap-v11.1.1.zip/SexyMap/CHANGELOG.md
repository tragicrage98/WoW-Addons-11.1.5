# SexyMap

## [v11.1.1](https://github.com/funkydude/SexyMap/tree/v11.1.1) (2025-04-21)
[Full Changelog](https://github.com/funkydude/SexyMap/compare/v11.1.0...v11.1.1) [Previous Releases](https://github.com/funkydude/SexyMap/releases)

- Fix other addons breaking the scale selection, closes #401  
