--[[
	Constants specific to Bagnon configuration menus
--]]

local CONFIG, Config = ...
Config.components = true
Config.componentMenuHeight = 105
Config.columns = true