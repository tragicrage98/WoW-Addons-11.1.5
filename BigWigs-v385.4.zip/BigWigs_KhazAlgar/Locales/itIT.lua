local L = BigWigs:NewBossLocale("Aggregation of Horrors", "itIT")
if not L then return end
if L then
	L.void_rocks = "Rocce del Vuoto" -- Plural of Void Rock (452379)
end
