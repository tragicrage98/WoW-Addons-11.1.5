local L = BigWigs:NewBossLocale("Aggregation of Horrors", "deDE")
if not L then return end
if L then
	L.void_rocks = "Leerenfelsen" -- Plural of Void Rock (452379)
end
