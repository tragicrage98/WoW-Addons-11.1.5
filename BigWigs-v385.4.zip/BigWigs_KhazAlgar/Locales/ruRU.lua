local L = BigWigs:NewBossLocale("Aggregation of Horrors", "ruRU")
if not L then return end
if L then
	--L.void_rocks = "Void Rocks" -- Plural of Void Rock (452379)
end
