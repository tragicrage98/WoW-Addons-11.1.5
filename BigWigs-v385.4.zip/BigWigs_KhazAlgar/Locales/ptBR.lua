local L = BigWigs:NewBossLocale("Aggregation of Horrors", "ptBR")
if not L then return end
if L then
	L.void_rocks = "Rochas Caóticas" -- Plural of Void Rock (452379)
end
