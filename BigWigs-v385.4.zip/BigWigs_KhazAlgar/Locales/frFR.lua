local L = BigWigs:NewBossLocale("Aggregation of Horrors", "frFR")
if not L then return end
if L then
	L.void_rocks = "Rochers du Vide" -- Plural of Void Rock (452379)
end
