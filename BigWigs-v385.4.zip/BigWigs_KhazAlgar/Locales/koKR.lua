local L = BigWigs:NewBossLocale("Aggregation of Horrors", "koKR")
if not L then return end
if L then
	L.void_rocks = "공허 바위" -- Plural of Void Rock (452379)
end
