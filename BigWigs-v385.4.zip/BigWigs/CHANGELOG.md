# BigWigs

## [v385.4](https://github.com/BigWigsMods/BigWigs/tree/v385.4) (2025-04-29)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v385.3...v385.4) [Previous Releases](https://github.com/BigWigsMods/BigWigs/releases)

- Loader: Test a minor change to error checking  
- Locales: Cleanup  
- Update zhCN (#2027)  
- Update koKR (#2026)  
