
local _, tbl = ...
tbl.isClassic = true
tbl.isTBC = true
tbl.season = 0
