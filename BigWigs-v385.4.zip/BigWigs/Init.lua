
local _, tbl = ...
tbl.isRetail = true
tbl.season = 0
