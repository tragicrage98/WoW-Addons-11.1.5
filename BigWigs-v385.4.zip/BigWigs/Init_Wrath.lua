
local _, tbl = ...
tbl.isClassic = true
tbl.isWrath = true
tbl.season = 0
