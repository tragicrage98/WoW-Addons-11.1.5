
local _, tbl = ...
tbl.isClassic = true
tbl.isCata = true
tbl.season = 0
