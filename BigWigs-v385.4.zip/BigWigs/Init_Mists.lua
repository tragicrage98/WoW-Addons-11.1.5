
local _, tbl = ...
tbl.isClassic = true
tbl.isMists = true
tbl.season = 0
