# Bartender4

## [4.15.8.1](https://github.com/Nevcairiel/Bartender4/tree/4.15.8.1) (2025-04-25)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.15.7...4.15.8.1) [Previous Releases](https://github.com/Nevcairiel/Bartender4/releases)

- Update TOC  
- Remove mention of discord, its not meant for user support  
