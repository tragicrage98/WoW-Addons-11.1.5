# v118

* Added a new approach to hooking POI vignettes.
* Updated TOC for 11.1.5

# v104

* Add toggle for faction restrictions
* Add toggle for class restrictions

# v101

* Added a feature that POIs can have tooltips.
* Updated core localizations: deDE, esES, frFR, zhCN

# v100

* Added new requirement type for specializations.
* Updated core localizations: esES

# v95

* Updated core localizations: zhTW

# v92

* Rares with uncollected reputation will now appear as purple skulls. This option only
  takes effect when "Reputation rewards" are toggled on.

# v90

* Updated core localizations: deDE, esES, frFr, zhCN

# v89

* Updated reward toggles in main menu to match dropdown menu.
* Hide manuscript toggle for expansions other than Dragonflight.

# v87

* Updated core localizations: deDE, frFR, zhCN

# v86

* Added new render links functionality for map and area ids.
* Added new option for hiding treasure if all rewards are known.
* Added new option to show NPC ids to input into other addons.

# v1

* Initial changelog entry.
